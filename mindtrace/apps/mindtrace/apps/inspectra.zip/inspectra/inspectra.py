from pydantic import BaseModel
from mindtrace.core import TaskSchema
from mindtrace.services import Service
# from mindtrace.database import Database

# pymongo, beanie - Uncomment when using MongoDB

class ConfigSchema(TaskSchema):
    name: str
    description: str
    version: str
    author: str
    author_email: str
    url: str


class InspectraService(Service):
    """
    Entire Inspectra service layer.
    Contains ALL domain logic for plants, lines, etc.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # self.plants = Database().collection("plants")
        # self.lines = Database().collection("lines")

        # Internal endpoints
        # self.add_endpoint("/config", self.config, schema=ConfigSchema)
        # self.add_endpoint("/plants/list", self.list_plants)
        # self.add_endpoint("/plants/create", self.create_plant)
        # self.add_endpoint("/lines/list", self.list_lines)
        # self.add_endpoint("/lines/create", self.create_line)

    #
    # CONFIG ENDPOINT
    #
    def config(self):
        return ConfigSchema(
            name="inspectra",
            description="Inspectra Platform",
            version="1.0.0",
            author="Inspectra",
            author_email="inspectra@inspectra.com",
            url="https://inspectra.com",
        )

    #
    # PLANTS
    #
    async def list_plants(self):
        return await self.plants.find({})

    async def create_plant(self, payload: dict):
        return await self.plants.insert_one(payload)

    #
    # LINES
    #
    async def list_lines(self):
        return await self.lines.find({})

    async def create_line(self, payload: dict):
        return await self.lines.insert_one(payload)


inspectra_service = InspectraService()