class Line:
    """Placeholder model."""
    pass
