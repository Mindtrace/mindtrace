class Plant:
    """Placeholder model."""
    pass
